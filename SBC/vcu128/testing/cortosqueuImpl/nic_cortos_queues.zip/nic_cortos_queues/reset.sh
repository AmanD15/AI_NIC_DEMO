cd ../../../vivado_synth
./reset.sh
cd -

#source /home/tools_shared/Vivado/2019.1/settings64.sh
#vivado -mode batch -source ./scripts/reset.tcl
